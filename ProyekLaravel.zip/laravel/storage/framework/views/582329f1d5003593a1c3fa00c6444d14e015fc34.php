<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Invoice <?php echo e($pesanan->invoice); ?></title>

    <style>
        html,
        body {
            margin: 10px;
            padding: 10px;
            font-family: sans-serif;
        }
        h1,h2,h3,h4,h5,h6,p,span,label {
            font-family: sans-serif;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 0px !important;
        }
        table thead th {
            height: 28px;
            text-align: left;
            font-size: 16px;
            font-family: sans-serif;
        }
        table, th, td {
            border: 1px solid #ddd;
            padding: 8px;
            font-size: 14px;
        }

        .heading {
            font-size: 24px;
            margin-top: 12px;
            margin-bottom: 12px;
            font-family: sans-serif;
        }
        .small-heading {
            font-size: 18px;
            font-family: sans-serif;
        }
        .total-heading {
            font-size: 18px;
            font-weight: 700;
            font-family: sans-serif;
        }
        .order-details tbody tr td:nth-child(1) {
            width: 20%;
        }
        .order-details tbody tr td:nth-child(3) {
            width: 20%;
        }

        .text-start {
            text-align: left;
        }
        .text-end {
            text-align: right;
        }
        .text-center {
            text-align: center;
        }
        .company-data span {
            margin-bottom: 4px;
            display: inline-block;
            font-family: sans-serif;
            font-size: 14px;
            font-weight: 400;
        }
        .no-border {
            border: 1px solid #fff !important;
        }
        .bg-blue {
            background-color: #414ab1;
            color: #fff;
        }
    </style>
</head>
<body>

    <table class="order-details">
        <thead>
            <tr>
                <th width="50%" colspan="2">
                    <h2 class="text-start">Alesha</h2>
                </th>
                <th width="50%" colspan="2" class="text-end company-data">
                    <span>Invoice : <?php echo e($pesanan->invoice); ?></span> <br>
                    <span>Tanggal: <?php echo e($pesanan->created_at->format('d-m-Y h:i A')); ?></span> <br>
                    <span>Status : <?php echo e($pesanan->status); ?></span> <br>
                    <span>Alamat: <?php echo e($pesanan->address_detail. ', ' . $pesanan->destination); ?></span> <br>
                </th>
            </tr>
            <tr class="bg-blue">
                <th width="50%" colspan="2">Order Details</th>
                <th width="50%" colspan="2">User Details</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Order Invoice:</td>
                <td><?php echo e($pesanan->invoice); ?></td>

                <td>Nama:</td>
                <td><?php echo e($pesanan->nama_order); ?></td>
            </tr>
           
            <tr>
                <td>Ordered Date:</td>
                <td><?php echo e($pesanan->created_at->format('d-m-Y h:i A')); ?></td>

                <td>Phone:</td>
                <td><?php echo e($pesanan->no_hp); ?></td>
            </tr>
            <tr>
                <td>Kurir:</td>
                <td><?php echo e($pesanan->courier); ?></td>

                <td>Alamat:</td>
                <td><?php echo e($pesanan->address_detail. ', ' . $pesanan->destination); ?></td>
            </tr>
            <tr>
                <td>Order Status:</td>
                <td><?php echo e($pesanan->status); ?></td>

                <td>Total:</td>
                <td>Rp <?php echo number_format($pesanan->total,0,',','.'); ?>,00</td>
            </tr>
        </tbody>
    </table>

    <br>
    <p class="text-center">
        Terimakasih Sudah Belanja di Alesha <span>:)</span>
    </p>

</body>
</html><?php /**PATH C:\laragon\www\ProyekLaravel\resources\views/client/invoice/generate_invoice.blade.php ENDPATH**/ ?>