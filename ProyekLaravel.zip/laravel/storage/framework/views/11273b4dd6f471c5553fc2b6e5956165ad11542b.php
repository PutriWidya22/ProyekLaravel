
<?php $__env->startSection('title', 'Product'); ?>

<?php $__env->startSection('header'); ?>
<div class="top-menu">
    <div class="container">
        <div class="row">
            <div class="col-sm-7 col-md-9">
                <div id="colorlib-logo"><a href="/">Alesha</a></div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 text-left menu-1">
                <ul>
                    <?php if(Auth::check()): ?>
                    <li><a href="/">Home</a></li>
                    <li class="active"><a href="/customer/product">Product</a></li>
                    <li><a href="/customer/about">About</a></li>
                    <li><a href="/customer/contact">Contact</a></li>

                    <?php
                    $pesanan_utama = \App\Models\Pesanan::where('user_id', session('id'))->where('id_order',0)->first();
                    if(!empty($pesanan_utama))
                       {
                        $notif = \App\Models\PesananDetail::where('pesanan_id', $pesanan_utama->id)->count(); 
                       }
                    ?>
                    <li class="cart"><a href="/customer/keranjang"><i class="icon-shopping-cart"></i>
                            <?php if(!empty($notif)): ?>
                            <span class="badge badge-danger"><?php echo e($notif); ?></span>
                            <?php endif; ?>
                        </a>
                    </li>

                    <li class="cart">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(session('name')); ?> <span class="caret"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="/logout">
                                <i class="bi bi-box-arrow-right"></i>
                                <span>Logout</span>
                            </a>
                            <a class="dropdown-item" href="/customer/checkout/riwayat">
                                <i class="bi bi-box-arrow-right"></i>
                                <span>Riwayat Belanja</span>
                            </a>
                        </div>
                    </li>

                    <?php else: ?>
                    <li><a href="/">Home</a></li>
                    <li class="active"><a href="/customer/product">Product</a></li>
                    <li><a href="/customer/about">About</a></li>
                    <li><a href="/customer/contact">Contact</a></li>
                    <li><a href="/login">Login</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col">
                <p class="bread"><span><a href="/">Home</a></span> / <span>Product</span></p>
            </div>
        </div>
    </div>
</div>

<div class="colorlib-about">
    <div class="container">
        <div class="row row-pb-md">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 mb-4 text-center">
                <div class="product-entry border">
                    <div class="card">
                        <img src="<?php echo e($d->gambar); ?>" class="img-fluid" >
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($d->nama_produk); ?></h5>
                            <p class="card-text">
                                <strong>Harga :</strong> Rp <?php echo number_format($d->harga,0,',','.'); ?>,00<br>
                                
                            </p>
                            <a href="/customer/detail/view/<?php echo e($d->id); ?>" class="btn btn-outline-primary"> Detail</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js" integrity="sha512-pumBsjNRGGqkPzKHndZMaAG+bir374sORyzM3uulLV14lN5LyykqNk8eEeUlUkB3U0M4FApyaHraT65ihJhDpQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.index.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProyekLaravel\resources\views/client/product/product.blade.php ENDPATH**/ ?>