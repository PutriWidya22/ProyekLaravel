
<?php $__env->startSection('content'); ?>

<section class="ftco-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12 col-lg-10">
                <div class="wrap d-md-flex">
                    <div class="img" style="background-image: url(<?php echo e(asset('03Login')); ?>/images/bg1.jpg);">
                    </div>
                    <div class="login-wrap p-4 p-md-5">

                        <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                        <?php endif; ?>

                        <?php if(session('errors')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('errors')->first()); ?>

                        </div>
                        <?php endif; ?>

                        <div class="d-flex">
                            <div class="w-100">
                                <h3 class="mb-4">Login Admin</h3>
                            </div>
                        </div>

                        <form action="/adminAksiLogin" class="signin-form" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-3">
                                <label for="email">Email</label>
                                <input type="email" name="email" id="email" class="form-control" placeholder="Email">
                            </div>
                            <div class="form-group mb-3">
                                <label for="password">Password</label>
                                <input type="password" name="password" id="password" class="form-control"
                                    placeholder="Password">
                            </div>
                            <div class="form-group">
                                <button type="submit"
                                    class="form-control btn btn-primary rounded submit px-3">Login</button>
                            </div>
                        </form>
                        <p>Belum punya akun?<a href="/register"> Register</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('login.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProyekLaravel\resources\views/login/loginadmin.blade.php ENDPATH**/ ?>