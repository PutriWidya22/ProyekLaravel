<footer id="colorlib-footer" role="contentinfo">
    <div class="container">
        <div class="row row-pb-md">
            <div class="col footer-col colorlib-widget">
                <h4>About Alesha</h4>
                <p>Website Alesha menyediakan berbagai jenis sepatu mulai dari Flastshoes, Sneakers, dan Wedges.</p>
            </div>
            <div class="col footer-col colorlib-widget">
                <h4>Customer Care</h4>
                <p>
                    <ul class="colorlib-footer-links">
                        <li><a href="/customer/contact">Contact</a></li>
                        <li><a href="/customer/keranjang">Cart</a></li>
                    </ul>
                </p>
            </div>
            <div class="col footer-col colorlib-widget">
                <h4>Information</h4>
                <p>
                    <ul class="colorlib-footer-links">
                        <li><a href="/customer/about">About us</a></li>
                    </ul>
                </p>
            </div>

            <div class="col footer-col">
                <h4>Contact Information</h4>
                <ul class="colorlib-footer-links">
                    <li>Jl. Anggrek No 02, <br> Bantul, Daerah Istimewa Yogyakarta</li>
                    <li><a href="https://wa.me/6285601535956?text=Mau%20bertanya%20tentang%20pembelian%20di%20toko%20Alesha">+62 856-0153-5956</a></li>
                    <li><a href="mailto:pw98421@gmail.com">Alesha@gmail.com</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="copy">
        <div class="row">
            <div class="col-sm-12 text-center">
                <p>
                    <span>Copyright &copy; Putri Widya. All rights reserved</span> 
                </p>
            </div>
        </div>
    </div>
</footer>