<div class="sale">
    <div class="container">
        <div class="row">
            <div class="col-sm-8 offset-sm-2 text-center">
                <div class="row">
                    <div class="owl-carousel2">
                        <div class="item">
                            <div class="col">
                                <h3><a href="">Sepatu termurah di yogyakarta</a></h3>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col">
                                <h3><a href="">Sepatu berkualitas tinggi</a></h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>